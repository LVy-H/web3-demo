import { ethers } from "hardhat";

async function main() {
    const [deployer] = await ethers.getSigners();
    console.log("Deploying contracts with the account:", deployer.address);

    // 1. Deploy Poseidon library
    const PoseidonT3Factory = await ethers.getContractFactory("PoseidonT3");
    const poseidonT3 = await PoseidonT3Factory.deploy();

    // 2. Deploy Semaphore verifier
    const SemaphoreVerifierFactory = await ethers.getContractFactory("MockSemaphoreVerifier");
    const semaphoreVerifier = await SemaphoreVerifierFactory.deploy();
    const verifierAddress = await semaphoreVerifier.getAddress();
    console.log("SemaphoreVerifier deployed to:", verifierAddress);

    // 3. Deploy Semaphore core utilizing Poseidon
    const SemaphoreFactory = await ethers.getContractFactory("Semaphore", {
        libraries: {
            "poseidon-solidity/PoseidonT3.sol:PoseidonT3": await poseidonT3.getAddress(),
        },
    });
    const semaphore = await SemaphoreFactory.deploy(verifierAddress);
    const semaphoreAddress = await semaphore.getAddress();
    console.log("Semaphore deployed to:", semaphoreAddress);

    console.log("\n==============================================");

    // 4. Deploy ZkVoting
    const ZkVotingFactory = await ethers.getContractFactory("ZkVoting");
    const zkVoting = await ZkVotingFactory.deploy(semaphoreAddress);
    console.log("ZkVoting deployed to:", await zkVoting.getAddress());

    // 5. Deploy ZkAirdrop
    // Providing 1 ETH as the airdrop claim amount per person
    const claimAmount = ethers.parseEther("1.0");
    const ZkAirdropFactory = await ethers.getContractFactory("ZkAirdrop");
    const zkAirdrop = await ZkAirdropFactory.deploy(semaphoreAddress, claimAmount);
    console.log("ZkAirdrop deployed to:", await zkAirdrop.getAddress());

    // Fund the airdrop contract with 10 ETH total pool
    const fundTx = await deployer.sendTransaction({
        to: await zkAirdrop.getAddress(),
        value: ethers.parseEther("10.0")
    });
    await fundTx.wait();
    console.log("ZkAirdrop funded with 10 ETH");

    console.log("==============================================\n");
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
